# Utility (Fabric, client-side, Minecraft 26.3)

| Key | What |
|---|---|
| **K** | Auto Attack: hits a player the moment your crosshair is on them and they are in reach. Waits for the attack cooldown. |
| **J** | Player ESP: boxes around every other player, visible through walls (also invisible players). Red = close, yellow = mid, green = far (60+ blocks). |

Both start OFF each time you join a world. Rebind under Controls > Utility.
Auto Attack pauses while a screen is open, while using an item, or while spectating.

Many multiplayer servers ban these. Use them in singleplayer, your own server, or where allowed.

Build: `gradle build` (Java 25). The jar is in `build/libs/`.
Project layout and build setup mirror the SchemLite reference mod.
