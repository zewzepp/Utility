# Utility (Fabric, client-side, Minecraft 26.3)

| Key | What |
|---|---|
| **K** | Auto Attack: hits a player the moment your crosshair is on them and they are in reach. Waits for the attack cooldown. |
| **J** | ESP: boxes and tracer lines around the selected target type, visible through walls. Red = close, yellow = mid, green = far (60+ blocks). |
| **O** | Switch ESP target between Players and Armor Stands. |

Both start OFF each time you join a world. Rebind under Controls > Utility.
Auto Attack pauses while a screen is open, while using an item, or while spectating.

Many multiplayer servers ban these. Use them in singleplayer, your own server, or where allowed.

Build: `gradle build` (Java 25). The jar is in `build/libs/`.
Project layout and build setup mirror the SchemLite reference mod.


- **J**: Toggle player hitbox ESP and tracer lines from your eyes to each player.
- **K**: Toggle auto attack while a player is under the crosshair.
- **L**: Toggle smooth camera lock to the nearest valid player within 64 blocks.

- **O**: Switch the ESP target between players and armor stands. This affects ESP only; camera lock and auto attack remain player-only. Armor stand ESP works in singleplayer/offline worlds when armor stands are loaded nearby.
