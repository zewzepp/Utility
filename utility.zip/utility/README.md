# Utility (Fabric, client-side, Minecraft 26.3)

| Key | Function |
|---|---|
| **J** | Toggle ESP boxes and tracer lines from your eyes to the selected targets. |
| **K** | Toggle Auto Attack. Attacks the selected target type when it is under the crosshair and the normal attack cooldown is ready. |
| **L** | Toggle smooth camera lock to the nearest selected target within 64 blocks. |
| **O** | Switch target mode between Players and Armor Stands. This selection applies to ESP, Auto Attack, and Camera Lock. |

Both ESP and combat features start OFF when joining a world. Rebind keys under Controls > Utility.

Auto Attack pauses while a screen is open, while using an item, or while spectating. Armor stand targeting is intended for singleplayer/offline testing or worlds where you have permission. Some servers may restrict automated targeting.

Build with Java 25 using `gradle build`. The JAR is generated in `build/libs/`.
