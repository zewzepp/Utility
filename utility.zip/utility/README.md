# Utility Fabric Mod

Player-only client utilities for Minecraft 26.3.

## Hotkeys
- **J**: Toggle Player ESP (hitbox and tracer)
- **K**: Toggle Auto Attack (players only)
- **L**: Toggle Camera Lock (players only)
- **O**: Open Camera Lock Settings

## Camera Lock speed
Use the slider in the settings screen to adjust camera-follow speed from 5% (slow/smooth) to 100% (fast). Changes apply immediately.

## Build
Requires Java 25 and Gradle. Run `gradle build` from this project directory.
