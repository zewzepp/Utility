package dev.utility;

import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** ESP for either other players or armor stands, selected in Utility. */
public final class Esp {
    private static final Map<Integer, Vec3[]> pos = new HashMap<>();
    private static java.lang.reflect.Method topM;
    private static boolean topResolved = false;
    private static java.lang.reflect.Method lineM;
    private static boolean lineResolved = false;

    private static void onTop(Object props) {
        if (props == null) return;
        try {
            if (!topResolved) {
                topResolved = true;
                try { topM = props.getClass().getMethod("setAlwaysOnTop"); topM.setAccessible(true); } catch (Throwable ignored) { }
            }
            if (topM != null) topM.invoke(props);
        } catch (Throwable ignored) { }
    }

    public static void clear() { pos.clear(); }

    private static void drawTracer(Vec3 start, Vec3 end, int color) {
        try {
            if (!lineResolved) {
                lineResolved = true;
                for (java.lang.reflect.Method method : Gizmos.class.getMethods()) {
                    Class<?>[] p = method.getParameterTypes();
                    if (method.getName().equals("line") && p.length == 3
                            && p[0] == Vec3.class && p[1] == Vec3.class
                            && p[2] == GizmoStyle.class) {
                        lineM = method;
                        break;
                    }
                }
            }
            if (lineM != null) lineM.invoke(null, start, end, GizmoStyle.stroke(color));
        } catch (Throwable ignored) { }
    }

    private static List<? extends Entity> targets(Minecraft mc) {
        List<Player> players = new ArrayList<>();
        for (Player player : mc.level.players()) {
            if (player != mc.player) players.add(player);
        }
        return players;
    }

    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        Set<Integer> seen = new HashSet<>();
        for (Entity entity : targets(mc)) {
            if (entity == mc.player || entity.isRemoved()) continue;
            int id = entity.getId();
            seen.add(id);
            Vec3 cur = entity.position();
            Vec3[] old = pos.get(id);
            pos.put(id, new Vec3[]{old != null ? old[1] : cur, cur});
        }
        pos.keySet().retainAll(seen);
    }

    private static float partialTick(Minecraft mc) {
        try {
            Object dt = Minecraft.class.getMethod("getDeltaTracker").invoke(mc);
            return (float) dt.getClass().getMethod("getGameTimeDeltaPartialTick", boolean.class).invoke(dt, false);
        } catch (Throwable t) { return 1.0f; }
    }

    public static void render() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        float pt = partialTick(mc);

        for (Entity entity : targets(mc)) {
            if (entity == mc.player || entity.isRemoved()) continue;
            if (entity instanceof Player player && (player.isSpectator() || !player.isAlive())) continue;

            Vec3[] v = pos.get(entity.getId());
            Vec3 cur = entity.position();
            Vec3 shown = v == null ? cur : v[0].add(v[1].subtract(v[0]).scale(pt));
            AABB box = entity.getBoundingBox().move(shown.subtract(cur));

            double d = mc.player.distanceTo(entity);
            float k = (float) Math.min(1.0, d / 60.0);
            int r = (int) (255 * Math.min(1.0, 2 * (1 - k)));
            int g = (int) (255 * Math.min(1.0, 2 * k));
            int color = 0xFF000000 | (r << 16) | (g << 8) | 0x20;

            onTop(Gizmos.cuboid(box, GizmoStyle.stroke(color)));
            drawTracer(mc.player.getEyePosition(), box.getCenter(), 0xFF35D9FF);
        }
    }

    private Esp() {}
}
