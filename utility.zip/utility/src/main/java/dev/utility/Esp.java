package dev.utility;

import net.minecraft.client.Minecraft;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Player ESP: draws a box around every other player, through walls (also shows invisible
 * players). Colour goes red (close) -> yellow -> green (far). Boxes are smoothed between
 * ticks so they don't stutter.
 */
public final class Esp {
    /** previous / current position of each player, recorded every tick */
    private static final Map<Integer, Vec3[]> pos = new HashMap<>();
    private static java.lang.reflect.Method topM;
    private static boolean topResolved = false;

    /** Makes a gizmo render through blocks (looked up by name so a rename can't break the build). */
    private static void onTop(Object props) {
        if (props == null) return;
        try {
            if (!topResolved) {
                topResolved = true;
                try { topM = props.getClass().getMethod("setAlwaysOnTop"); topM.setAccessible(true); } catch (Throwable ignored) { }
            }
            if (topM != null) topM.invoke(props);
        } catch (Throwable ignored) { }
    }

    public static void clear() { pos.clear(); }

    public static void tick(Minecraft mc) {
        if (mc.level == null) return;
        Set<Integer> seen = new HashSet<>();
        for (Player pl : mc.level.players()) {
            if (pl == mc.player) continue;
            int id = pl.getId();
            seen.add(id);
            Vec3 cur = pl.position();
            Vec3[] old = pos.get(id);
            pos.put(id, new Vec3[]{ old != null ? old[1] : cur, cur });
        }
        pos.keySet().retainAll(seen);
    }

    private static float partialTick(Minecraft mc) {
        try {
            Object dt = Minecraft.class.getMethod("getDeltaTracker").invoke(mc);
            return (float) dt.getClass().getMethod("getGameTimeDeltaPartialTick", boolean.class).invoke(dt, false);
        } catch (Throwable t) { return 1.0f; }
    }

    public static void render() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        float pt = partialTick(mc);

        for (Player pl : mc.level.players()) {
            if (pl == mc.player || pl.isSpectator() || !pl.isAlive()) continue;
            Vec3[] v = pos.get(pl.getId());
            Vec3 cur = pl.position();
            Vec3 shown = v == null ? cur : v[0].add(v[1].subtract(v[0]).scale(pt));
            AABB box = pl.getBoundingBox().move(shown.subtract(cur)).inflate(0.05);

            double d = mc.player.distanceTo(pl);
            float k = (float) Math.min(1.0, d / 60.0);               // 0 = close, 1 = far (60+ blocks)
            int r = (int) (255 * Math.min(1.0, 2 * (1 - k)));
            int g = (int) (255 * Math.min(1.0, 2 * k));
            int color = 0xFF000000 | (r << 16) | (g << 8) | 0x20;

            onTop(Gizmos.cuboid(box, GizmoStyle.stroke(color)));
        }
    }
    private Esp() {}
}
