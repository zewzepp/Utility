package dev.utility;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Smoothly turns the local camera toward the nearest entity in the selected ESP mode. */
public final class AimLock {
    private static int targetId = -1;
    private static final double MAX_DISTANCE = 64.0;
    private static final float TURN_SPEED = 0.35f;

    public static void clear() { targetId = -1; }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null) { clear(); return; }
        Player self = mc.player;
        Entity target = findTarget(mc, self);
        if (target == null) { clear(); return; }
        targetId = target.getId();

        Vec3 delta = target.getEyePosition().subtract(self.getEyePosition());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float wantedYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float wantedPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        self.setYRot(self.getYRot() + wrapDegrees(wantedYaw - self.getYRot()) * TURN_SPEED);
        self.setXRot(self.getXRot() + (wantedPitch - self.getXRot()) * TURN_SPEED);
    }

    private static Entity findTarget(Minecraft mc, Player self) {
        Entity current = targetId == -1 ? null : mc.level.getEntity(targetId);
        if (valid(current, self) && self.distanceTo(current) <= MAX_DISTANCE) return current;

        Entity best = null;
        double bestDistance = MAX_DISTANCE;
        if (Utility.armorStandEsp) {
            for (ArmorStand candidate : mc.level.getEntitiesOfClass(ArmorStand.class, self.getBoundingBox().inflate(MAX_DISTANCE))) {
                if (!valid(candidate, self)) continue;
                double distance = self.distanceTo(candidate);
                if (distance < bestDistance) { bestDistance = distance; best = candidate; }
            }
        } else {
            for (Player candidate : mc.level.players()) {
                if (!valid(candidate, self)) continue;
                double distance = self.distanceTo(candidate);
                if (distance < bestDistance) { bestDistance = distance; best = candidate; }
            }
        }
        return best;
    }

    private static boolean valid(Entity candidate, Player self) {
        if (candidate == null || candidate == self || candidate.isRemoved() || !candidate.isAlive()) return false;
        if (Utility.armorStandEsp) return candidate instanceof ArmorStand;
        return candidate instanceof Player player && !player.isSpectator();
    }

    private static float wrapDegrees(float value) {
        value %= 360.0f;
        if (value >= 180.0f) value -= 360.0f;
        if (value < -180.0f) value += 360.0f;
        return value;
    }

    private AimLock() {}
}
