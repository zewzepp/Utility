package dev.utility;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;

/** Utility: client-side Auto Attack (K) and Player ESP (J). */
public class Utility implements ClientModInitializer {
    static KeyMapping TRIGGER, ESP;
    static boolean triggerOn = false;
    static boolean espOn = false;

    private static KeyMapping key(String id, int code, KeyMapping.Category cat) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.utility." + id, InputConstants.Type.values()[0], code, cat));
    }

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("utility", "main"));
        TRIGGER = key("trigger", 75, cat);   // K
        ESP = key("esp", 74, cat);           // J

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null || mc.gameMode == null) {
                triggerOn = false; espOn = false;
                Esp.clear();
                while (TRIGGER.consumeClick()) { }
                while (ESP.consumeClick()) { }
                return;
            }

            while (TRIGGER.consumeClick()) {
                triggerOn = !triggerOn;
                actionBar("Auto Attack: " + (triggerOn ? "ON" : "OFF"));
            }
            while (ESP.consumeClick()) {
                espOn = !espOn;
                if (!espOn) Esp.clear();
                actionBar("Player ESP: " + (espOn ? "ON" : "OFF"));
            }

            if (triggerOn) Combat.tick(mc);
            if (espOn) Esp.tick(mc);
        });

        LevelRenderEvents.BEFORE_GIZMOS.register(ctx -> { if (espOn) Esp.render(); });
    }

    /** Action-bar message (not chat). Silently does nothing if the API differs. */
    static void actionBar(String s) {
        try {
            Minecraft mc = Minecraft.getInstance();
            Object gui = Minecraft.class.getField("gui").get(mc);
            Method m = gui.getClass().getMethod("setOverlayMessage", Component.class, boolean.class);
            m.invoke(gui, Component.literal(s), false);
        } catch (Throwable ignored) { }
    }
}
