package dev.utility;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.lang.reflect.Method;

/** Utility: player-only ESP, auto attack, and configurable camera lock. */
public class Utility implements ClientModInitializer {
    static KeyMapping TRIGGER, ESP, AIM_LOCK, SETTINGS;
    static boolean triggerOn = false;
    static boolean espOn = false;
    static boolean aimLockOn = false;

    private static KeyMapping key(String id, int code, KeyMapping.Category cat) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping("key.utility." + id, InputConstants.Type.values()[0], code, cat));
    }

    @Override
    public void onInitializeClient() {
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("utility", "main"));
        TRIGGER = key("trigger", 75, cat);   // K
        ESP = key("esp", 74, cat);           // J
        AIM_LOCK = key("aim_lock", 76, cat); // L
        SETTINGS = key("settings", 79, cat); // O

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null || mc.gameMode == null) {
                triggerOn = false; espOn = false; aimLockOn = false;
                AimLock.clear();
                Esp.clear();
                while (TRIGGER.consumeClick()) { }
                while (ESP.consumeClick()) { }
                while (AIM_LOCK.consumeClick()) { }
                while (SETTINGS.consumeClick()) { }
                return;
            }

            while (TRIGGER.consumeClick()) {
                triggerOn = !triggerOn;
                actionBar("Auto Attack: " + (triggerOn ? "ON" : "OFF"));
            }
            while (ESP.consumeClick()) {
                espOn = !espOn;
                if (!espOn) Esp.clear();
                actionBar("Player ESP: " + (espOn ? "ON" : "OFF"));
            }

            while (AIM_LOCK.consumeClick()) {
                aimLockOn = !aimLockOn;
                if (!aimLockOn) AimLock.clear();
                actionBar("Camera Lock: " + (aimLockOn ? "ON" : "OFF"));
            }

            while (SETTINGS.consumeClick()) {
                mc.gui.setScreen(new AimSettingsScreen());
            }

            if (aimLockOn && !Combat.screenOpen(mc)) AimLock.tick(mc);
            if (triggerOn) Combat.tick(mc);
            if (espOn) Esp.tick(mc);
        });

        LevelRenderEvents.BEFORE_GIZMOS.register(ctx -> { if (espOn) Esp.render(); });
    }

    /** Action-bar message (not chat). Silently does nothing if the API differs. */
    static void actionBar(String s) {
        try {
            Minecraft mc = Minecraft.getInstance();
            Object gui = Minecraft.class.getField("gui").get(mc);
            Method m = gui.getClass().getMethod("setOverlayMessage", Component.class, boolean.class);
            m.invoke(gui, Component.literal(s), false);
        } catch (Throwable ignored) { }
    }
}
