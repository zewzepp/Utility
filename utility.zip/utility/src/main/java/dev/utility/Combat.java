package dev.utility;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * Auto attack: hits a player as soon as the crosshair is on them. The vanilla crosshair
 * target already respects reach, so it only fires when they are in range.
 */
public final class Combat {
    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return;
        if (mc.screen != null || p.isSpectator() || p.isUsingItem()) return;

        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult ehr
                && ehr.getEntity() instanceof Player target
                && target != p
                && target.isAlive()
                && !target.isSpectator()
                && p.getAttackStrengthScale(0.5f) >= 1.0f) {   // only full-strength hits
            mc.gameMode.attack(p, target);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }
    private Combat() {}
}
