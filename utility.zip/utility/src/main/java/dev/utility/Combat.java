package dev.utility;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Auto attack for the entity type selected with the O key. */
public final class Combat {
    private static Field screenF;
    private static Method screenM;
    private static boolean screenResolved = false;
    private static Constructor<?> swingCtor;
    private static boolean swingResolved = false;

    /** True when any menu/screen is open (inventory, pause, chat...). */
    static boolean screenOpen(Minecraft mc) {
        try {
            if (!screenResolved) {
                screenResolved = true;
                try { screenF = Minecraft.class.getField("screen"); } catch (Throwable ignored) { }
                if (screenF == null) {
                    try { screenF = Minecraft.class.getDeclaredField("screen"); screenF.setAccessible(true); } catch (Throwable ignored) { }
                }
                if (screenF == null) {
                    for (String n : new String[]{"screen", "getScreen"}) {
                        try { screenM = Minecraft.class.getMethod(n); break; } catch (Throwable ignored) { }
                    }
                }
            }
            if (screenF != null) return screenF.get(mc) != null;
            if (screenM != null) return screenM.invoke(mc) != null;
            Object mh = Minecraft.class.getField("mouseHandler").get(mc);
            return !(boolean) mh.getClass().getMethod("isMouseGrabbed").invoke(mh);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Tells the server (and other players) that you swung your arm. */
    private static void swing(LocalPlayer p) {
        try {
            if (!swingResolved) {
                swingResolved = true;
                Class<?> c = Class.forName("net.minecraft.network.protocol.game.ServerboundSwingPacket");
                swingCtor = c.getConstructor(InteractionHand.class);
            }
            if (swingCtor != null) p.connection.send((net.minecraft.network.protocol.Packet<?>) swingCtor.newInstance(InteractionHand.MAIN_HAND));
        } catch (Throwable ignored) { }
    }

    private static boolean selectedTarget(Entity target, LocalPlayer self) {
        if (target == null || target == self || target.isRemoved() || !target.isAlive()) return false;
        if (Utility.armorStandEsp) return target instanceof ArmorStand;
        return target instanceof Player player && !player.isSpectator();
    }

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null) return;
        if (screenOpen(mc) || p.isSpectator() || p.isUsingItem()) return;

        HitResult hit = mc.hitResult;
        if (hit instanceof EntityHitResult ehr
                && selectedTarget(ehr.getEntity(), p)
                && p.getAttackStrengthScale(0.5f) >= 1.0f) {
            mc.gameMode.attack(p, ehr.getEntity());
            swing(p);
        }
    }
    private Combat() {}
}
