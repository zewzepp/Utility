package dev.utility;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** In-game settings screen for camera-lock tracking speed. */
public final class AimSettingsScreen extends Screen {
    private SpeedSlider speedSlider;

    public AimSettingsScreen() {
        super(Component.literal("Camera Lock Settings"));
    }

    @Override
    protected void init() {
        int sliderWidth = Math.min(260, this.width - 40);
        int x = (this.width - sliderWidth) / 2;
        int y = this.height / 2 - 10;
        speedSlider = new SpeedSlider(x, y, sliderWidth, 20, AimLock.getTurnSpeed());
        addRenderableWidget(speedSlider);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(font, title, width / 2, height / 2 - 48, 0xFFFFFF);
        graphics.drawCenteredString(font, "Lower = smoother, higher = faster", width / 2, height / 2 - 30, 0xB0B0B0);
    }

    private static final class SpeedSlider extends AbstractSliderButton {
        SpeedSlider(int x, int y, int width, int height, float speed) {
            super(x, y, width, height, Component.empty(), (speed - 0.05) / 0.95);
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            int percent = Math.round((float) (0.05 + value * 0.95) * 100);
            setMessage(Component.literal("Camera follow speed: " + percent + "%"));
        }

        @Override
        protected void applyValue() {
            AimLock.setTurnSpeed((float) (0.05 + value * 0.95));
        }
    }
}
